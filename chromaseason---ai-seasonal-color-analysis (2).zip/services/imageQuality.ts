
import { ImageQualityResult } from "../types";

// Helper: Calculate luminance
const getLuminance = (r: number, g: number, b: number) => 0.2126 * r + 0.7152 * g + 0.0722 * b;

export const analyzeImageQuality = (
  imageSource: HTMLVideoElement | HTMLImageElement
): ImageQualityResult => {
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d");

  // Standardize size for analysis to improve performance
  const width = 200;
  const height = 200;
  canvas.width = width;
  canvas.height = height;

  if (!ctx) {
    return {
      isValid: true,
      brightness: "good",
      contrast: "good",
      lightingColor: "neutral",
      score: 100,
      issues: [],
    };
  }

  // Draw image to canvas
  ctx.drawImage(imageSource, 0, 0, width, height);
  const imageData = ctx.getImageData(0, 0, width, height);
  const data = imageData.data;

  let totalR = 0, totalG = 0, totalB = 0;
  let totalLuminance = 0;
  const luminances: number[] = [];

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];

    totalR += r;
    totalG += g;
    totalB += b;

    // Relative luminance formula
    const luminance = getLuminance(r, g, b);
    totalLuminance += luminance;
    luminances.push(luminance);
  }

  const pixelCount = width * height;
  const avgR = totalR / pixelCount;
  const avgG = totalG / pixelCount;
  const avgB = totalB / pixelCount;
  const avgLuminance = totalLuminance / pixelCount;

  // Calculate Contrast (Standard Deviation of Luminance)
  let luminanceVariance = 0;
  for (const l of luminances) {
    luminanceVariance += Math.pow(l - avgLuminance, 2);
  }
  const luminanceStdDev = Math.sqrt(luminanceVariance / pixelCount);

  // Analysis Logic
  const issues: string[] = [];
  let score = 100;

  // 1. Brightness Check
  let brightnessStatus: 'good' | 'too_dark' | 'too_bright' = 'good';
  if (avgLuminance < 60) {
    brightnessStatus = 'too_dark';
    score -= 30;
    issues.push('lighting_too_dark');
  } else if (avgLuminance > 220) {
    brightnessStatus = 'too_bright';
    score -= 30;
    issues.push('lighting_too_bright');
  }

  // 2. Contrast Check (Washed out / Foggy)
  let contrastStatus: 'good' | 'too_low' = 'good';
  if (luminanceStdDev < 20) {
    contrastStatus = 'too_low';
    score -= 20;
    issues.push('contrast_too_low');
  }

  // 3. Color Cast Check (Simple White Balance)
  // Check if one channel is significantly stronger than others
  let lightingColor: 'neutral' | 'too_warm' | 'too_cool' = 'neutral';
  
  // Warm cast (Yellow/Red dominance)
  if (avgR > avgB + 30 && avgG > avgB + 10) {
    lightingColor = 'too_warm';
    score -= 10;
    // We don't block upload for warmth, but we warn
    issues.push('lighting_warm_cast');
  } 
  // Cool cast (Blue dominance)
  else if (avgB > avgR + 30) {
    lightingColor = 'too_cool';
    score -= 10;
    issues.push('lighting_cool_cast');
  }

  const isValid = score > 60; // Threshold for acceptance

  return {
    isValid,
    brightness: brightnessStatus,
    contrast: contrastStatus,
    lightingColor,
    score,
    issues
  };
};

/**
 * Applies automatic white balance correction to an image canvas.
 * Uses a modified Gray World assumption / Max-RGB technique.
 */
export const applyAutoWhiteBalance = (canvas: HTMLCanvasElement): void => {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const width = canvas.width;
  const height = canvas.height;
  const imageData = ctx.getImageData(0, 0, width, height);
  const data = imageData.data;

  // 1. Find the brightest pixels (highlights) to serve as white reference
  // We don't just take the single max, we take the top 1% to avoid noise
  let maxR = 0, maxG = 0, maxB = 0;
  
  // Find crude maxes first
  for (let i = 0; i < data.length; i += 4) {
    maxR = Math.max(maxR, data[i]);
    maxG = Math.max(maxG, data[i+1]);
    maxB = Math.max(maxB, data[i+2]);
  }

  // Normalize channels
  // If the image is "warm", Red is high and Blue is low. We need to boost Blue.
  // Target is the max luminance found.
  const globalMax = Math.max(maxR, maxG, maxB);
  
  // Gain factors
  const scaleR = globalMax / (maxR || 1);
  const scaleG = globalMax / (maxG || 1);
  const scaleB = globalMax / (maxB || 1);

  // Apply scaling
  for (let i = 0; i < data.length; i += 4) {
    data[i] = Math.min(255, data[i] * scaleR);     // R
    data[i+1] = Math.min(255, data[i+1] * scaleG); // G
    data[i+2] = Math.min(255, data[i+2] * scaleB); // B
  }

  ctx.putImageData(imageData, 0, 0);
};
