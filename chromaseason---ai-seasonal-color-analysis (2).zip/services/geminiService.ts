
import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult, SeasonType, Language } from "../types";

// Minified instructions for speed while retaining core logic
const getSystemInstruction = (lang: Language) => `
Act as a Color Science Expert. Perform deterministic Seasonal Color Analysis.
CONSISTENCY RULE: Same image input MUST yield same output. Anchor on pixel data.

**ANALYSIS PROTOCOL**
1. **ROI**: Mask eyes/lips/hair. Sample "True Skin" from jawline/cheek.
2. **CIELAB Extraction**: 
   - L* (Lightness): Value (0-100).
   - b* (Blue-Yellow): +b=Warm, -b=Cool.
3. **Logic**:
   - Spring: Warm + Light + Clear
   - Summer: Cool + Light + Muted
   - Autumn: Warm + Deep + Muted
   - Winter: Cool + Deep + Clear
4. **Consistency**:
   - IF Spring: scales.warmToCool < 50.
   - IF Summer: scales.warmToCool > 50.
   - IF Autumn: scales.warmToCool < 50.
   - IF Winter: scales.warmToCool > 60, contrast > 70.

**COMPARATIVE (All 4 Seasons)**:
Evaluate match for Spring, Summer, Autumn, Winter. Score (0-100) and specific Reason (e.g. "Skin glows", "Shadows appear"). Matches.season MUST match top score.

**DAILY FASHION COLORS**:
- RETURN SOPHISTICATED TEXTILE COLORS (e.g. "Navy", "Oatmeal", "Sage"), NOT digital RGB.
- **Wardrobe Basics**: 3-4 neutrals for coats/pants.
- **Daily Accents**: 4-5 flattering top colors.

**OUTPUT**: JSON.
- Enum keys in English.
- **ALL USER TEXT** in ${lang === 'zh' ? 'Chinese (Simplified)' : 'English'}.
- Specifics: subtype, description, reason, color names, recommendations.
- If image poor: prefix description with "ERROR:".
`;

const RESPONSE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    season: { type: Type.STRING, enum: [SeasonType.Spring, SeasonType.Summer, SeasonType.Autumn, SeasonType.Winter] },
    secondarySeason: { type: Type.STRING, enum: [SeasonType.Spring, SeasonType.Summer, SeasonType.Autumn, SeasonType.Winter] },
    worstSeason: { type: Type.STRING, enum: [SeasonType.Spring, SeasonType.Summer, SeasonType.Autumn, SeasonType.Winter] },
    subtype: { type: Type.STRING },
    description: { type: Type.STRING },
    
    // NEW COMPARATIVE SECTION
    seasonMatches: {
      type: Type.OBJECT,
      properties: {
        spring: { 
            type: Type.OBJECT, 
            properties: { 
                season: { type: Type.STRING, enum: [SeasonType.Spring] }, 
                score: { type: Type.NUMBER }, 
                reason: { type: Type.STRING, description: "Max 10 words reason" } 
            } 
        },
        summer: { 
            type: Type.OBJECT, 
            properties: { 
                season: { type: Type.STRING, enum: [SeasonType.Summer] }, 
                score: { type: Type.NUMBER }, 
                reason: { type: Type.STRING, description: "Max 10 words reason" } 
            } 
        },
        autumn: { 
            type: Type.OBJECT, 
            properties: { 
                season: { type: Type.STRING, enum: [SeasonType.Autumn] }, 
                score: { type: Type.NUMBER }, 
                reason: { type: Type.STRING, description: "Max 10 words reason" } 
            } 
        },
        winter: { 
            type: Type.OBJECT, 
            properties: { 
                season: { type: Type.STRING, enum: [SeasonType.Winter] }, 
                score: { type: Type.NUMBER }, 
                reason: { type: Type.STRING, description: "Max 10 words reason" } 
            } 
        },
      }
    },

    skinAnalysis: {
      type: Type.OBJECT,
      properties: {
        regions: {
          type: Type.OBJECT,
          properties: {
            forehead: { type: Type.STRING, description: "Hex color code" },
            cheek: { type: Type.STRING, description: "Hex color code ignoring redness" },
            neck: { type: Type.STRING, description: "Hex color code" }
          }
        },
        dimensions: {
          type: Type.OBJECT,
          properties: {
            hueAngle: { type: Type.NUMBER, description: "Estimated Hue Angle 0-360" },
            value: { type: Type.NUMBER, description: "0-100 Lightness" },
            chroma: { type: Type.NUMBER, description: "0-100 Saturation" }
          }
        },
        contrastMethod: {
          type: Type.OBJECT,
          properties: {
            whiteBackgroundResult: { type: Type.STRING, description: "How skin reacts to white" },
            reactionToGold: { type: Type.STRING },
            reactionToSilver: { type: Type.STRING }
          }
        }
      }
    },

    scales: {
      type: Type.OBJECT,
      properties: {
        warmToCool: { type: Type.NUMBER, description: "0=Warm, 50=Neutral, 100=Cool" },
        lightToDeep: { type: Type.NUMBER, description: "0=Light, 100=Deep" },
        brightToMuted: { type: Type.NUMBER, description: "0=Bright/Clear, 100=Muted/Soft" },
        contrastLevel: { type: Type.NUMBER, description: "0=Low, 100=High" }
      }
    },
    
    pccsTones: {
      type: Type.ARRAY,
      items: { type: Type.STRING, enum: ['pale', 'light', 'bright', 'vivid', 'light_grayish', 'soft', 'strong', 'grayish', 'dull', 'deep', 'dark_grayish', 'dark'] }
    },

    volume: { type: Type.STRING, enum: ['Small', 'Medium', 'Large'] },
    shape: { type: Type.STRING, enum: ['Curved', 'Straight', 'Natural'] },

    features: {
      type: Type.OBJECT,
      properties: {
        skinTone: { type: Type.STRING },
        eyeColor: { type: Type.STRING },
        hairColor: { type: Type.STRING },
      },
    },
    palette: {
      type: Type.OBJECT,
      properties: {
        bestColors: {
          type: Type.ARRAY,
          items: { type: Type.OBJECT, properties: { hex: { type: Type.STRING }, name: { type: Type.STRING } } }
        },
        worstColors: {
          type: Type.ARRAY,
          items: { type: Type.OBJECT, properties: { hex: { type: Type.STRING }, name: { type: Type.STRING } } }
        },
        neutrals: {
          type: Type.ARRAY,
          items: { type: Type.OBJECT, properties: { hex: { type: Type.STRING }, name: { type: Type.STRING } } }
        },
      },
    },
    recommendations: {
      type: Type.OBJECT,
      properties: {
        makeup: {
          type: Type.OBJECT,
          properties: {
            foundation: { type: Type.STRING },
            blush: { type: Type.STRING },
            lipstick: { type: Type.STRING },
            eyeshadow: { type: Type.STRING },
          },
        },
        jewelry: { type: Type.STRING },
        fashionTips: { type: Type.STRING },
      },
    },
    
    bestMetals: { type: Type.ARRAY, items: { type: Type.STRING, enum: ['Gold', 'Silver', 'Rose Gold', 'Champagne'] } },
    hairColors: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { hex: { type: Type.STRING }, name: { type: Type.STRING } } } },
    contactLenses: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { hex: { type: Type.STRING }, name: { type: Type.STRING } } } },
    perfumeNotes: { type: Type.ARRAY, items: { type: Type.STRING } },
    fabricTextures: { type: Type.ARRAY, items: { type: Type.STRING } },
    accessoryMaterials: { type: Type.ARRAY, items: { type: Type.STRING } },

    visualGuide: {
      type: Type.OBJECT,
      properties: {
        makeupLook: { type: Type.STRING, enum: ['peach', 'rose', 'berry', 'red', 'nude', 'contrast'] },
        metal: { type: Type.STRING, enum: ['gold', 'silver', 'rose_gold'] },
        fabric: { type: Type.STRING, enum: ['linen', 'silk', 'wool', 'leather', 'denim'] },
      },
    },
    stylePersona: {
      type: Type.OBJECT,
      properties: {
        keywords: { type: Type.ARRAY, items: { type: Type.STRING } },
        description: { type: Type.STRING },
      },
    },
  },
  required: ["season", "secondarySeason", "worstSeason", "seasonMatches", "skinAnalysis", "scales", "pccsTones", "volume", "shape", "subtype", "description", "features", "palette", "recommendations", "visualGuide", "stylePersona", "bestMetals", "hairColors", "contactLenses", "perfumeNotes", "fabricTextures", "accessoryMaterials"],
};

export const analyzeImage = async (base64Image: string, lang: Language): Promise<AnalysisResult> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const base64Data = base64Image.split(',')[1] || base64Image;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          { inlineData: { mimeType: "image/jpeg", data: base64Data } },
          { text: `Analyze seasonal color palette. Output language: ${lang === 'zh' ? 'Chinese (Simplified)' : 'English'}.` },
        ],
      },
      config: {
        systemInstruction: getSystemInstruction(lang),
        responseMimeType: "application/json",
        responseSchema: RESPONSE_SCHEMA,
        temperature: 0, 
        topK: 1, 
        topP: 0.1, 
        seed: 42, 
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");
    
    const result = JSON.parse(text) as AnalysisResult;

    if (result.description && result.description.startsWith("ERROR:")) {
       throw new Error(result.description.replace("ERROR:", "").trim());
    }

    return result;

  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw error;
  }
};
