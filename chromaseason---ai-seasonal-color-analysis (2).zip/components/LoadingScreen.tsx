
import React, { useEffect, useState } from 'react';
import { Language } from '../types';
import { getTranslation } from '../translations';

interface LoadingScreenProps {
  lang: Language;
}

const LoadingScreen: React.FC<LoadingScreenProps> = ({ lang }) => {
  const t = getTranslation(lang);
  
  // Parse steps from translation string
  // Assumes format: "Step 1: ...\nStep 2: ...\nStep 3: ..."
  const steps = t.loading.desc.split('\n').filter(s => s.trim().length > 0);
  
  const [activeStep, setActiveStep] = useState(0);

  // Simulate progress through steps
  useEffect(() => {
    const intervals = [2000, 2500, 3000]; // Duration for each step
    let currentStep = 0;

    const advanceStep = () => {
      if (currentStep < steps.length - 1) {
        currentStep++;
        setActiveStep(currentStep);
        setTimeout(advanceStep, intervals[currentStep] || 2000);
      }
    };

    const initialTimer = setTimeout(advanceStep, intervals[0]);

    return () => clearTimeout(initialTimer);
  }, [steps.length]);

  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] w-full max-w-lg mx-auto p-8 animate-fade-in">
      
      {/* Central Visual Loader */}
      <div className="relative w-32 h-32 mb-12">
        {/* Outer Ring */}
        <div className="absolute inset-0 rounded-full border-2 border-stone-100"></div>
        
        {/* Rotating/Breathing Gradient Ring */}
        <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-rose-200 via-stone-100 to-blue-200 opacity-50 blur-xl animate-pulse"></div>
        <div className="absolute inset-2 rounded-full border-[3px] border-transparent border-t-stone-800 border-l-stone-800/50 animate-spin duration-[3s]"></div>
        
        {/* Inner Icon */}
        <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-3xl animate-bounce">✨</span>
        </div>
      </div>

      <h3 className="text-2xl font-serif text-stone-900 mb-8 tracking-wide text-center">
        {t.loading.title}
      </h3>

      {/* Steps List */}
      <div className="w-full space-y-4">
        {steps.map((stepText, index) => {
          const isActive = index === activeStep;
          const isCompleted = index < activeStep;
          const isPending = index > activeStep;

          return (
            <div 
              key={index}
              className={`flex items-center p-4 rounded-xl border transition-all duration-500 ${
                isActive 
                  ? 'bg-white border-stone-200 shadow-md scale-105' 
                  : isCompleted 
                    ? 'bg-stone-50 border-transparent opacity-60' 
                    : 'bg-transparent border-transparent opacity-30'
              }`}
            >
              {/* Status Icon */}
              <div className="mr-4 flex-shrink-0">
                {isCompleted ? (
                  <div className="w-6 h-6 rounded-full bg-stone-800 text-white flex items-center justify-center">
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                ) : isActive ? (
                  <div className="w-6 h-6 rounded-full border-2 border-stone-300 border-t-stone-800 animate-spin"></div>
                ) : (
                  <div className="w-6 h-6 rounded-full border-2 border-stone-200"></div>
                )}
              </div>

              {/* Text */}
              <div className="flex-grow">
                <span className={`text-sm font-medium ${isActive ? 'text-stone-800' : 'text-stone-500'}`}>
                  {stepText}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default LoadingScreen;
