import React from 'react';
import { Language } from '../types';
import { getTranslation } from '../translations';

interface HeroProps {
  onStart: () => void;
  lang: Language;
}

const Hero: React.FC<HeroProps> = ({ onStart, lang }) => {
  const t = getTranslation(lang);

  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] text-center px-4 animate-fade-in">
      <div className="mb-6 inline-block p-2 bg-white rounded-2xl shadow-sm rotate-3 transform hover:rotate-6 transition-transform duration-500">
         <div className="w-24 h-24 md:w-32 md:h-32 rounded-xl bg-gradient-to-br from-rose-200 via-rose-300 to-rose-200 flex items-center justify-center text-3xl">
            🌸
         </div>
      </div>
      
      <h1 className="text-5xl md:text-7xl font-serif text-stone-900 mb-6 tracking-tight">
        {t.hero.title} <br />
        <span className="italic text-transparent bg-clip-text bg-gradient-to-r from-rose-400 via-orange-400 to-amber-400">
            {t.hero.titleHighlight}
        </span>
      </h1>
      
      <p className="max-w-xl text-lg md:text-xl text-stone-500 mb-10 leading-relaxed font-light">
        {t.hero.subtitle}
      </p>
      
      <button 
        onClick={onStart}
        className="group relative px-8 py-4 bg-stone-900 text-stone-50 text-lg font-medium rounded-full overflow-hidden shadow-xl hover:shadow-2xl transition-all hover:-translate-y-1"
      >
        <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-stone-800 to-stone-900 opacity-0 group-hover:opacity-100 transition-opacity"></span>
        <span className="relative flex items-center">
          {t.hero.cta}
          <svg className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
          </svg>
        </span>
      </button>

      <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm font-medium text-stone-400 uppercase tracking-widest">
         {t.hero.seasons.map((season, idx) => (
           <span key={idx}>{season}</span>
         ))}
      </div>
    </div>
  );
};

export default Hero;