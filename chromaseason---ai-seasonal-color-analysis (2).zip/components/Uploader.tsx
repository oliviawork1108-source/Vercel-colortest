
import React, { useCallback, useRef, useState, useEffect } from 'react';
import { CameraIcon, UploadIcon } from './Icons';
import { Language, ImageQualityResult } from '../types';
import { getTranslation } from '../translations';
import { analyzeImageQuality, applyAutoWhiteBalance } from '../services/imageQuality';

interface UploaderProps {
  onImageSelected: (base64: string) => void;
  lang: Language;
}

const Uploader: React.FC<UploaderProps> = ({ onImageSelected, lang }) => {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  
  // Quality Check State
  const [qualityResult, setQualityResult] = useState<ImageQualityResult | null>(null);
  const [analyzingQuality, setAnalyzingQuality] = useState(false);

  const t = getTranslation(lang);

  // --- Processing Helper ---
  const processImageForAnalysis = (imageElement: HTMLImageElement | HTMLVideoElement): string => {
    // Create a temporary canvas
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    // Set dimensions (cap at 768p for speed optimization)
    // 768px is sufficient for color analysis and drastically reduces token count/latency
    let width = imageElement instanceof HTMLVideoElement ? imageElement.videoWidth : imageElement.width;
    let height = imageElement instanceof HTMLVideoElement ? imageElement.videoHeight : imageElement.height;
    
    // Resize logic if too big
    const MAX_DIM = 768; 
    if (width > MAX_DIM || height > MAX_DIM) {
      const ratio = Math.min(MAX_DIM / width, MAX_DIM / height);
      width *= ratio;
      height *= ratio;
    }

    canvas.width = width;
    canvas.height = height;
    
    if (ctx) {
       // 1. Draw original
       if (imageElement instanceof HTMLVideoElement) {
          // Flip for camera mirror
          ctx.translate(width, 0);
          ctx.scale(-1, 1);
          ctx.drawImage(imageElement, 0, 0, width, height);
          ctx.setTransform(1, 0, 0, 1, 0, 0); // Reset
       } else {
          ctx.drawImage(imageElement, 0, 0, width, height);
       }

       // 2. Apply Auto-Correction (Lighting/White Balance)
       applyAutoWhiteBalance(canvas);
       
       // 3. Compress heavily (0.6) for speed. Color data is preserved well enough for AI.
       return canvas.toDataURL('image/jpeg', 0.6);
    }
    return '';
  };

  // --- File Upload Handling ---
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) return;
    
    setAnalyzingQuality(true);
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result as string;
      
      const img = new Image();
      img.onload = () => {
        // 1. Check Quality
        const result = analyzeImageQuality(img);
        setQualityResult(result);
        setAnalyzingQuality(false);
        
        if (result.isValid) {
          // 2. If valid, process (Resize + White Balance) and submit
          const processedBase64 = processImageForAnalysis(img);
          if (processedBase64) {
             onImageSelected(processedBase64);
          } else {
             // Fallback
             onImageSelected(base64);
          }
        } else {
          // Auto-clear error after 4 seconds
          setTimeout(() => setQualityResult(null), 4000);
        }
      };
      img.src = base64;
    };
    reader.readAsDataURL(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) processFile(file);
  };

  // --- Camera & Real-time Analysis Handling ---
  const startCamera = async () => {
    try {
      setIsCameraOpen(true);
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } } 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error("Camera error:", err);
      alert(t.uploader.cameraError);
      setIsCameraOpen(false);
    }
  };

  // Real-time analysis loop
  useEffect(() => {
    let intervalId: number;
    if (isCameraOpen && videoRef.current) {
      intervalId = window.setInterval(() => {
        if (videoRef.current && videoRef.current.readyState === 4) {
          const result = analyzeImageQuality(videoRef.current);
          setQualityResult(result);
        }
      }, 500); // Check every 500ms
    }
    return () => clearInterval(intervalId);
  }, [isCameraOpen]);

  const capturePhoto = () => {
    // Prevent capture if quality is bad
    if (qualityResult && !qualityResult.isValid) return;

    if (videoRef.current) {
        // Use the process helper to apply WB and correct formatting
        const processedBase64 = processImageForAnalysis(videoRef.current);
        if (processedBase64) {
           stopCamera();
           onImageSelected(processedBase64);
        }
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsCameraOpen(false);
    setQualityResult(null);
  };

  // --- UI Helpers ---
  const getQualityMessage = () => {
    if (!qualityResult) return null;
    if (qualityResult.isValid && qualityResult.issues.length === 0) {
      return <div className="text-green-400 font-medium flex items-center justify-center"><span className="mr-2">✓</span> {t.uploader.quality.good}</div>;
    }
    
    // Map issues to messages
    const msgs: string[] = [];
    if (qualityResult.issues.includes('lighting_too_dark')) msgs.push(t.uploader.quality.too_dark);
    if (qualityResult.issues.includes('lighting_too_bright')) msgs.push(t.uploader.quality.too_bright);
    if (qualityResult.issues.includes('contrast_too_low')) msgs.push(t.uploader.quality.too_low);
    if (qualityResult.issues.includes('lighting_warm_cast')) msgs.push(t.uploader.quality.warm_cast);
    if (qualityResult.issues.includes('lighting_cool_cast')) msgs.push(t.uploader.quality.cool_cast);

    return (
      <div className={`${qualityResult.isValid ? 'text-yellow-400' : 'text-red-400'} font-medium`}>
        {msgs.length > 0 ? msgs[0] : t.uploader.quality.rejected}
      </div>
    );
  };

  return (
    <div className="w-full max-w-2xl mx-auto animate-fade-in px-4 py-8">
      {/* Header */}
      <div className="text-center mb-10">
        <h2 className="text-4xl font-serif text-stone-900 mb-4 tracking-tight">{t.uploader.title}</h2>
        <p className="text-stone-500 font-light text-lg">
          {t.uploader.desc}
        </p>
      </div>

      {/* Guidelines Card - Refined */}
      <div className="bg-white rounded-2xl p-8 mb-10 shadow-sm border border-stone-100/80">
        <h4 className="text-xs font-bold text-stone-300 uppercase tracking-[0.2em] mb-8 text-center">
            {t.uploader.guidelines.title}
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* Guideline 1 */}
          <div className="flex flex-col items-center text-center group">
             <div className="w-16 h-16 bg-amber-50 text-amber-500 rounded-full flex items-center justify-center text-3xl mb-5 shadow-sm ring-4 ring-amber-50/50 transition-transform group-hover:scale-110">
                ☀️
             </div>
             <p className="text-sm font-medium text-stone-600 leading-relaxed px-2">
                {t.uploader.guidelines.light}
             </p>
          </div>
          
          {/* Guideline 2 */}
          <div className="flex flex-col items-center text-center relative group">
             {/* Dividers for Desktop */}
             <div className="hidden md:block absolute left-0 top-1/2 -translate-y-1/2 -ml-4 h-16 w-px bg-gradient-to-b from-transparent via-stone-100 to-transparent"></div>
             <div className="hidden md:block absolute right-0 top-1/2 -translate-y-1/2 -mr-4 h-16 w-px bg-gradient-to-b from-transparent via-stone-100 to-transparent"></div>
             
             <div className="w-16 h-16 bg-rose-50 text-rose-500 rounded-full flex items-center justify-center text-3xl mb-5 shadow-sm ring-4 ring-rose-50/50 transition-transform group-hover:scale-110">
                🚫
             </div>
             <p className="text-sm font-medium text-stone-600 leading-relaxed px-2">
                {t.uploader.guidelines.shadow}
             </p>
          </div>

          {/* Guideline 3 */}
          <div className="flex flex-col items-center text-center group">
             <div className="w-16 h-16 bg-stone-100 text-stone-500 rounded-full flex items-center justify-center text-3xl mb-5 shadow-sm ring-4 ring-stone-100/50 transition-transform group-hover:scale-110">
                😐
             </div>
             <p className="text-sm font-medium text-stone-600 leading-relaxed px-2">
                {t.uploader.guidelines.clean}
             </p>
          </div>
        </div>
      </div>

      {/* Upload Area - Exquisite Design */}
      {!isCameraOpen ? (
        <div className="bg-white p-3 rounded-3xl shadow-xl shadow-stone-200/40 border border-stone-100">
          <div 
            className={`
              border-2 border-dashed rounded-2xl h-80 
              flex flex-col items-center justify-center 
              transition-all duration-300 cursor-pointer relative
              ${isDragging 
                ? 'border-stone-800 bg-stone-50 scale-[0.99]' 
                : 'border-stone-200 hover:border-stone-400 hover:bg-stone-50/30'
              }
            `}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
          >
            <div className="w-20 h-20 bg-stone-100 rounded-full mb-6 flex items-center justify-center text-stone-500 shadow-inner group-hover:scale-110 transition-transform">
              <UploadIcon className="w-8 h-8" />
            </div>
            
            <p className="text-lg font-serif font-medium text-stone-800 mb-2">
                {isDragging ? t.uploader.dropActive : t.uploader.drop}
            </p>
            <p className="text-xs text-stone-400 font-bold uppercase tracking-wider">{t.uploader.format}</p>
            
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/*" 
              onChange={handleFileChange}
            />

            {/* Error Message Overlay for File Upload */}
            {qualityResult && !qualityResult.isValid && (
              <div className="absolute inset-0 bg-white/95 flex items-center justify-center flex-col rounded-2xl z-10 animate-fade-in">
                 <div className="text-rose-500 text-3xl mb-3">⚠️</div>
                 <div className="text-stone-800 font-bold mb-2">{t.uploader.quality.rejected}</div>
                 <div className="text-stone-500 text-sm px-8 text-center max-w-xs">{getQualityMessage()}</div>
              </div>
            )}
             {analyzingQuality && (
               <div className="absolute inset-0 bg-white/90 flex items-center justify-center rounded-2xl z-10">
                 <div className="animate-spin w-8 h-8 border-2 border-stone-800 border-t-transparent rounded-full mr-3"></div>
                 <span className="text-stone-600 font-medium tracking-wide">{t.uploader.quality.analyzing}</span>
               </div>
            )}

          </div>
          
          <div className="mt-8 mb-4 px-4 text-center">
            <div className="relative flex items-center justify-center mb-8">
                <span className="bg-white px-4 text-stone-300 text-xs font-bold uppercase tracking-widest relative z-10">{t.uploader.or}</span>
                <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-stone-100"></div>
                </div>
            </div>
            
            <button 
              onClick={(e) => { e.stopPropagation(); startCamera(); }}
              className="w-full flex items-center justify-center px-6 py-4 border border-stone-200 rounded-xl text-stone-600 hover:text-stone-900 hover:border-stone-400 hover:bg-white hover:shadow-lg transition-all font-medium group bg-stone-50"
            >
              <CameraIcon className="w-5 h-5 mr-3 group-hover:scale-110 transition-transform" />
              {t.uploader.selfie}
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-stone-900 rounded-[2rem] overflow-hidden shadow-2xl relative ring-8 ring-stone-900">
          <div className="relative">
            <video 
              ref={videoRef} 
              autoPlay 
              playsInline 
              muted 
              className="w-full h-[600px] object-cover transform scale-x-[-1]" // Mirror effect
            />
            
            {/* Virtual Viewfinder / Face Guide Overlay */}
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center opacity-40">
               <svg viewBox="0 0 100 100" className="w-full h-full p-12">
                  {/* Head Oval */}
                  <ellipse cx="50" cy="45" rx="22" ry="30" fill="none" stroke="white" strokeWidth="0.5" strokeDasharray="2 2" />
                  {/* Eye Line */}
                  <line x1="38" y1="40" x2="62" y2="40" stroke="white" strokeWidth="0.5" />
                  {/* Center Line */}
                  <line x1="50" y1="20" x2="50" y2="70" stroke="white" strokeWidth="0.5" strokeDasharray="2 2" />
               </svg>
            </div>

            {/* Real-time Quality Feedback Overlay */}
            <div className="absolute top-6 left-0 right-0 flex justify-center z-20">
               <div className={`px-6 py-2 rounded-full backdrop-blur-md shadow-lg text-sm font-medium border flex items-center ${qualityResult?.isValid ? 'bg-black/40 border-green-400/30 text-green-400' : 'bg-black/60 border-rose-500/30 text-rose-400'}`}>
                 {analyzingQuality ? (
                    <span className="text-white flex items-center">
                        <span className="animate-spin w-3 h-3 border-2 border-white border-t-transparent rounded-full mr-2"></span>
                        {t.uploader.quality.analyzing}
                    </span>
                 ) : (
                    getQualityMessage()
                 )}
               </div>
            </div>
          </div>
          
          <div className="absolute bottom-10 left-0 right-0 flex justify-center items-center space-x-12 z-20">
             <button 
              onClick={stopCamera}
              className="text-white/80 hover:text-white text-sm font-medium bg-black/20 hover:bg-black/40 px-6 py-2 rounded-full backdrop-blur-md transition-colors"
            >
              {t.uploader.cancel}
            </button>
            <button 
              onClick={capturePhoto}
              disabled={qualityResult ? !qualityResult.isValid : true}
              className={`w-20 h-20 rounded-full border-[6px] flex items-center justify-center transition-all duration-300 ${qualityResult?.isValid ? 'border-white hover:scale-105 cursor-pointer shadow-[0_0_20px_rgba(255,255,255,0.3)]' : 'border-rose-500/50 opacity-50 cursor-not-allowed'}`}
            >
              <div className={`w-16 h-16 rounded-full transition-transform duration-200 ${qualityResult?.isValid ? 'bg-white active:scale-90' : 'bg-transparent'}`}></div>
            </button>
            <div className="w-16"></div> {/* Spacer for balance */}
          </div>
          
          {/* Gradient Overlay at bottom */}
          <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-black/80 to-transparent pointer-events-none"></div>
        </div>
      )}
    </div>
  );
};

export default Uploader;
