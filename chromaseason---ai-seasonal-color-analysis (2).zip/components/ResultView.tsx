
import React, { useRef, useState, useEffect } from 'react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { AnalysisResult, ColorSwatch, SeasonType, Language, SeasonMatch } from '../types';
import { RefreshIcon } from './Icons';
import { getTranslation } from '../translations';

interface ResultViewProps {
  result: AnalysisResult;
  userImage: string;
  onReset: () => void;
  lang: Language;
}

// Visual helpers
const getSeasonTheme = (season: SeasonType) => {
  switch (season) {
    case SeasonType.Spring: return { bg: 'bg-[#FFF5F5]', accent: 'text-rose-500', border: 'border-rose-200', gradient: 'from-orange-50 to-rose-100' };
    case SeasonType.Summer: return { bg: 'bg-[#F0F9FF]', accent: 'text-sky-500', border: 'border-sky-200', gradient: 'from-slate-50 to-sky-100' };
    case SeasonType.Autumn: return { bg: 'bg-[#FFFBEB]', accent: 'text-amber-700', border: 'border-amber-200', gradient: 'from-orange-50 to-amber-100' };
    case SeasonType.Winter: return { bg: 'bg-[#FAFAFA]', accent: 'text-indigo-600', border: 'border-indigo-200', gradient: 'from-gray-50 to-indigo-50' };
    default: return { bg: 'bg-stone-50', accent: 'text-stone-500', border: 'border-stone-200', gradient: 'from-stone-50 to-stone-100' };
  }
};

// Elegant Line Scale
const ScaleBar: React.FC<{ leftLabel: string; rightLabel: string; value: number; colorStart: string; colorEnd: string }> = ({ 
  leftLabel, rightLabel, value, colorStart, colorEnd 
}) => (
  <div className="mb-8">
    <div className="flex justify-between text-[10px] font-bold text-stone-400 uppercase tracking-widest mb-3">
      <span>{leftLabel}</span>
      <span>{rightLabel}</span>
    </div>
    <div className="relative h-2 w-full rounded-full bg-stone-100">
      {/* Gradient Track */}
      <div 
        className="absolute inset-0 rounded-full opacity-30"
        style={{ background: `linear-gradient(to right, ${colorStart}, ${colorEnd})` }}
      ></div>
      
      {/* Needle Indicator */}
      <div 
        className="absolute top-1/2 -mt-2 w-4 h-4 bg-white border-2 border-stone-800 rounded-full shadow-lg transform -translate-x-1/2 transition-all duration-1000 z-10 flex items-center justify-center"
        style={{ left: `${value}%` }}
      >
        <div className="w-1 h-1 bg-stone-800 rounded-full"></div>
      </div>
    </div>
  </div>
);

const DimensionBar: React.FC<{ label: string; value: number; unit?: string }> = ({ label, value, unit = "" }) => (
    <div className="flex items-center justify-between text-xs mb-4 group">
        <span className="text-stone-500 font-bold uppercase tracking-wider w-24">{label}</span>
        <div className="flex-grow mx-4 h-1.5 bg-stone-100 rounded-full overflow-hidden">
            <div className="h-full bg-stone-800 rounded-full transition-all duration-1000" style={{ width: `${value > 100 ? 100 : value}%` }}></div>
        </div>
        <span className="font-mono font-medium text-stone-900 w-10 text-right">{value}{unit}</span>
    </div>
);

const CheckBoxItem: React.FC<{ label: string; checked: boolean }> = ({ label, checked }) => (
  <div className={`flex items-center space-x-3 py-2 px-3 rounded-lg transition-all ${checked ? 'bg-stone-900 text-white shadow-md' : 'bg-transparent text-stone-400 border border-stone-100'}`}>
    <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${checked ? 'border-white' : 'border-stone-300'}`}>
      {checked && <div className="w-2 h-2 bg-white rounded-full"></div>}
    </div>
    <span className="text-xs font-bold uppercase tracking-wide">{label}</span>
  </div>
);

// --- NEW COMPONENT: Seasonal Comparison Module (Detailed 4-way view) ---
const SeasonalComparisonModule: React.FC<{ 
    activeSeason: SeasonType, 
    lang: Language, 
    userImage: string,
    matches: { spring: SeasonMatch, summer: SeasonMatch, autumn: SeasonMatch, winter: SeasonMatch } 
}> = ({ activeSeason, lang, userImage, matches }) => {
    
    // Translation Helper
    const t = getTranslation(lang);
    const seasonNames = t.seasons || {
        "Spring": "Spring",
        "Summer": "Summer",
        "Autumn": "Autumn",
        "Winter": "Winter"
    };

    // Zoom State
    // We store the full item object to render in the modal
    const [zoomedItem, setZoomedItem] = useState<any | null>(null);

    // Close on Escape key
    useEffect(() => {
        const handleEsc = (e: KeyboardEvent) => {
            if (e.key === 'Escape') setZoomedItem(null);
        };
        window.addEventListener('keydown', handleEsc);
        return () => window.removeEventListener('keydown', handleEsc);
    }, []);

    // Seasonal Palettes for the "Draping" Backgrounds
    const comparisonData = [
        {
            id: SeasonType.Spring,
            matchData: matches.spring,
            label: seasonNames[SeasonType.Spring] || 'Spring',
            // Bright, Warm, Clear
            drapes: ['#FFB7B2', '#FFDAC1', '#FFF59D', '#B5EAD7', '#C7CEEA'], 
            accent: 'border-orange-200 text-orange-800 bg-orange-50'
        },
        {
            id: SeasonType.Summer,
            matchData: matches.summer,
            label: seasonNames[SeasonType.Summer] || 'Summer',
            // Cool, Muted, Light
            drapes: ['#E1BEE7', '#F8BBD0', '#E0F7FA', '#B3E5FC', '#D1C4E9'],
            accent: 'border-blue-200 text-blue-800 bg-blue-50'
        },
        {
            id: SeasonType.Autumn,
            matchData: matches.autumn,
            label: seasonNames[SeasonType.Autumn] || 'Autumn',
            // Warm, Deep, Muted
            drapes: ['#D7CCC8', '#FFCCBC', '#F0F4C3', '#C5E1A5', '#A1887F'],
            accent: 'border-amber-200 text-amber-800 bg-amber-50'
        },
        {
            id: SeasonType.Winter,
            matchData: matches.winter,
            label: seasonNames[SeasonType.Winter] || 'Winter',
            // Cool, Vivid, Deep
            drapes: ['#E0E0E0', '#F5F5F5', '#B2EBF2', '#B39DDB', '#90CAF9'],
            accent: 'border-indigo-200 text-indigo-800 bg-indigo-50'
        }
    ];

    return (
        <div className="w-full">
            {/* Added ID for export targeting */}
            <div id="grid-comparison" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {comparisonData.map((item) => {
                    const isBest = activeSeason === item.id;
                    
                    return (
                        <div 
                            key={item.id} 
                            onClick={() => setZoomedItem(item)}
                            className={`relative group overflow-hidden rounded-2xl border-2 transition-all duration-500 break-inside-avoid cursor-pointer ${isBest ? 'border-stone-800 shadow-2xl scale-[1.02]' : 'border-stone-100 shadow-sm opacity-90 hover:opacity-100 hover:scale-[1.01]'}`}
                        >
                            {/* Hover Overlay Hint */}
                            <div className="absolute inset-0 z-20 bg-black/0 group-hover:bg-black/5 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100 pointer-events-none">
                                <div className="bg-white/90 backdrop-blur-sm rounded-full p-2 shadow-lg">
                                    <svg className="w-6 h-6 text-stone-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
                                    </svg>
                                </div>
                            </div>

                            {/* 1. Virtual Draping Background (Stripes) */}
                            <div className="absolute inset-0 flex opacity-60">
                                {item.drapes.map((color, i) => (
                                    <div key={i} className="flex-1 h-full" style={{ backgroundColor: color }}></div>
                                ))}
                            </div>
                            
                            {/* 2. Content Layer */}
                            <div className="relative p-6 flex flex-col items-center h-full">
                                
                                {/* Header */}
                                <div className={`px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-widest mb-4 ${item.accent} backdrop-blur-sm border`}>
                                    {item.label}
                                </div>

                                {/* Photo Simulated Draping */}
                                <div className="relative w-32 h-32 mb-6">
                                    {/* White Border Ring simulating cutout */}
                                    <div className="absolute inset-0 rounded-full border-[6px] border-white/80 shadow-lg z-10 overflow-hidden">
                                        <img src={userImage} className="w-full h-full object-cover" alt="analysis" />
                                    </div>
                                    {/* Glow behind head */}
                                    <div className="absolute inset-0 bg-white/40 blur-xl rounded-full transform scale-110"></div>
                                </div>

                                {/* Score Indicator */}
                                <div className="w-full mb-4">
                                    <div className="flex justify-between text-xs font-bold text-stone-700 mb-1">
                                        <span>{t.result.harmony || 'Harmony'}</span>
                                        <span>{item.matchData.score}%</span>
                                    </div>
                                    <div className="h-2 w-full bg-white/50 rounded-full overflow-hidden backdrop-blur-sm">
                                        <div 
                                            className="h-full bg-stone-800 transition-all duration-1000" 
                                            style={{ width: `${item.matchData.score}%` }}
                                        ></div>
                                    </div>
                                </div>

                                {/* Reasoning Box */}
                                <div className="mt-auto w-full bg-white/80 backdrop-blur-md p-3 rounded-lg border border-white/50 text-center min-h-[60px] flex items-center justify-center">
                                    <p className="text-[10px] md:text-xs text-stone-600 leading-snug font-medium">
                                        "{item.matchData.reason}"
                                    </p>
                                </div>

                                {/* Best Match Stamp */}
                                {isBest && (
                                    <div className="absolute top-4 right-4">
                                        <div className="bg-stone-900 text-white text-[10px] font-bold px-2 py-1 rounded shadow-lg flex items-center">
                                            <span className="mr-1">★</span> {t.result.bestMatch || 'BEST'}
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>

            {/* --- ZOOM MODAL --- */}
            {zoomedItem && (
                <div 
                    className="fixed inset-0 z-50 flex items-center justify-center bg-stone-900/80 backdrop-blur-md p-4 animate-fade-in"
                    onClick={() => setZoomedItem(null)}
                >
                    <div 
                        className="relative w-full max-w-lg bg-white rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
                        onClick={(e) => e.stopPropagation()}
                    >
                        {/* Close Button */}
                        <button 
                            className="absolute top-4 right-4 z-30 bg-black/20 hover:bg-black/40 text-white rounded-full p-2 transition-colors"
                            onClick={() => setZoomedItem(null)}
                        >
                            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>

                        {/* Modal Header */}
                        <div className="p-6 pb-2 bg-white z-20">
                             <div className={`inline-block px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest ${zoomedItem.accent} border`}>
                                {zoomedItem.label}
                            </div>
                        </div>
                        
                        {/* Expanded Draping View */}
                        <div className="relative flex-grow min-h-[400px]">
                             {/* Background Stripes (Larger) */}
                             <div className="absolute inset-0 flex">
                                {zoomedItem.drapes.map((color: string, i: number) => (
                                    <div key={i} className="flex-1 h-full" style={{ backgroundColor: color }}></div>
                                ))}
                            </div>
                            
                            {/* Large Photo Center */}
                            <div className="absolute inset-0 flex items-center justify-center p-8">
                                <div className="relative w-64 h-64 md:w-80 md:h-80">
                                     {/* Cutout Ring */}
                                     <div className="absolute inset-0 rounded-full border-[10px] border-white shadow-2xl overflow-hidden z-10">
                                         <img src={userImage} className="w-full h-full object-cover" alt="Large analysis" />
                                     </div>
                                </div>
                            </div>
                        </div>

                        {/* Modal Footer Info */}
                        <div className="bg-white p-6 z-20 border-t border-stone-100">
                             <div className="flex justify-between items-end mb-4">
                                <div>
                                    <span className="text-xs font-bold text-stone-400 uppercase">{t.result.harmony || 'Harmony'}</span>
                                    <div className="text-3xl font-serif text-stone-900">{zoomedItem.matchData.score}%</div>
                                </div>
                                {activeSeason === zoomedItem.id && (
                                    <div className="bg-stone-900 text-white px-3 py-1 rounded text-xs font-bold">
                                        ★ {t.result.bestMatch || 'BEST'}
                                    </div>
                                )}
                             </div>
                             
                             <div className="bg-stone-50 p-4 rounded-xl border border-stone-100">
                                 <p className="text-sm text-stone-700 leading-relaxed font-medium">
                                     "{zoomedItem.matchData.reason}"
                                 </p>
                             </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

const SectionHeader: React.FC<{ number: string; title: string }> = ({ number, title }) => (
    <div className="flex items-center mb-8 border-b border-stone-100 pb-4 break-after-avoid">
        <span className="font-mono text-xs text-stone-400 mr-4">/{number}</span>
        <h3 className="text-lg font-serif font-bold text-stone-900 uppercase tracking-widest">{title}</h3>
    </div>
);

const ResultView: React.FC<ResultViewProps> = ({ result, userImage, onReset, lang }) => {
  const t = getTranslation(lang);
  const reportRef = useRef<HTMLDivElement>(null);
  const [isDownloading, setIsDownloading] = useState(false);
  
  const seasonName = t.seasons ? t.seasons[result.season] : result.season;
  const secondarySeasonName = t.seasons ? t.seasons[result.secondarySeason] : result.secondarySeason;
  const worstSeasonName = t.seasons ? t.seasons[result.worstSeason] : result.worstSeason;
  
  const theme = getSeasonTheme(result.season);

  const handleDownload = async () => {
    if (!reportRef.current) return;
    setIsDownloading(true);
    try {
      // Force a small delay to ensure rendering is stable and images are ready
      await new Promise(resolve => setTimeout(resolve, 200));

      const canvas = await html2canvas(reportRef.current, {
        useCORS: true,
        scale: 2, // High resolution for print
        backgroundColor: '#FFFFFF',
        logging: false,
        windowWidth: 1920, // Force large desktop viewport
        onclone: (clonedDoc) => {
            const reportEl = clonedDoc.getElementById('report-container');
            if (reportEl) {
                // Force fixed width for consistency
                reportEl.style.width = '1200px'; 
                reportEl.style.maxWidth = '1200px';
                reportEl.style.margin = '0 auto';
                reportEl.style.padding = '60px';
                
                // Force Grid Layouts (Override Tailwind Responsive Classes for capture)
                const gridHero = clonedDoc.getElementById('grid-hero');
                if (gridHero) gridHero.style.gridTemplateColumns = 'repeat(12, minmax(0, 1fr))';
                
                const gridSkin = clonedDoc.getElementById('grid-skin');
                if (gridSkin) gridSkin.style.gridTemplateColumns = 'repeat(3, minmax(0, 1fr))';
                
                const gridScales = clonedDoc.getElementById('grid-scales');
                if (gridScales) gridScales.style.gridTemplateColumns = 'repeat(2, minmax(0, 1fr))';
                
                const gridComparison = clonedDoc.getElementById('grid-comparison');
                if (gridComparison) gridComparison.style.gridTemplateColumns = 'repeat(4, minmax(0, 1fr))';

                const gridStyle = clonedDoc.getElementById('grid-style');
                if (gridStyle) gridStyle.style.gridTemplateColumns = 'repeat(2, minmax(0, 1fr))';

                const gridRecs = clonedDoc.getElementById('grid-recs');
                if (gridRecs) gridRecs.style.gridTemplateColumns = 'repeat(3, minmax(0, 1fr))';

                const gridPalette = clonedDoc.getElementById('grid-palette');
                if (gridPalette) gridPalette.style.gridTemplateColumns = 'repeat(2, minmax(0, 1fr))';
            }
        }
      });

      const imgData = canvas.toDataURL('image/png');
      
      // Calculate PDF Dimensions (A4)
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });
      
      const imgWidth = 210; // A4 width mm
      const pageHeight = 297; // A4 height mm
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      
      let heightLeft = imgHeight;
      let position = 0;
      
      // First page
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
      
      // Subsequent pages if content is long
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save('ChromaSeason-Report.pdf');

    } catch (err) {
      console.error("Download failed", err);
      alert(lang === 'zh' ? "生成报告失败，请重试" : "Failed to generate report. Please try again.");
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="animate-fade-in pb-20 max-w-6xl mx-auto print:max-w-none print:pb-0">
      
      {/* --- REPORT CONTAINER --- */}
      <div 
        ref={reportRef} 
        id="report-container"
        className="bg-white p-6 md:p-16 shadow-2xl rounded-none md:rounded-[4px] max-w-[1200px] mx-auto text-stone-900 print:shadow-none print:p-0"
      >
        
        {/* Header */}
        <div className="flex justify-between items-end border-b-2 border-stone-900 pb-8 mb-12">
            <div>
                <h1 className="text-4xl md:text-5xl font-serif font-bold tracking-tight mb-2">{t.result.reportTitle}</h1>
                <p className="text-xs font-bold text-stone-400 uppercase tracking-[0.3em]">AI Seasonal Color Analysis</p>
            </div>
            <div className="hidden md:block text-right">
                <div className="w-16 h-16 border border-stone-200 rounded-full flex items-center justify-center">
                    <span className="font-serif italic text-2xl">Cs</span>
                </div>
            </div>
        </div>

        {/* 01. Scientific Skin Analysis (Moved to 01) */}
        <SectionHeader number="01" title={t.result.skinAnalysisTitle} />
        <div id="grid-skin" className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-16 items-center break-inside-avoid">
            <div className="flex flex-col items-center">
                <div className="relative w-48 h-48 rounded-full overflow-hidden shadow-xl ring-4 ring-stone-50 mb-6">
                    <img src={userImage} className="w-full h-full object-cover" alt="User" />
                </div>
                {/* Sampling Dots - Uniform Layout */}
                <div className="flex space-x-4">
                    {[
                        { color: result.skinAnalysis.regions.forehead, label: t.result.forehead },
                        { color: result.skinAnalysis.regions.cheek, label: t.result.cheek },
                        { color: result.skinAnalysis.regions.neck, label: t.result.neck }
                    ].map((item, i) => (
                        <div key={i} className="flex flex-col items-center group">
                            <div className="w-8 h-8 rounded-full shadow-inner ring-1 ring-stone-200 mb-2 transition-transform hover:scale-110" style={{backgroundColor: item.color}}></div>
                            <span className="text-[9px] uppercase font-bold text-stone-400">{item.label}</span>
                        </div>
                    ))}
                </div>
            </div>

            <div className="md:col-span-2">
                <div className="bg-stone-50/50 p-8 rounded-xl border border-stone-100">
                    <DimensionBar label={t.result.hue} value={result.skinAnalysis.dimensions.hueAngle} unit="°" />
                    <DimensionBar label={t.result.value} value={result.skinAnalysis.dimensions.value} />
                    <DimensionBar label={t.result.chroma} value={result.skinAnalysis.dimensions.chroma} />
                    
                    <div className="mt-8 pt-6 border-t border-stone-200">
                        <p className="text-sm text-stone-600 font-serif italic">
                            "<strong className="not-italic text-stone-900 font-sans text-xs uppercase tracking-wide mr-1">{t.result.contrastMethod}:</strong> 
                            {result.skinAnalysis.contrastMethod.whiteBackgroundResult}"
                        </p>
                    </div>
                </div>
            </div>
        </div>

        {/* 02. Personal Colors Hero (Moved to 02) */}
        <SectionHeader number="02" title={t.result.personalColor} />
        <div id="grid-hero" className="grid grid-cols-1 md:grid-cols-12 gap-8 mb-16 break-inside-avoid">
             <div className={`md:col-span-8 p-10 relative overflow-hidden rounded-xl bg-gradient-to-br ${theme.gradient} border border-white shadow-sm`}>
                 <div className="relative z-10">
                     <span className="block text-xs font-bold uppercase tracking-[0.2em] text-stone-500 mb-4">{t.result.bestSeason}</span>
                     <h2 className="text-6xl md:text-8xl font-serif text-stone-900 mb-6">{seasonName}</h2>
                     <div className="inline-block px-4 py-2 bg-white/60 backdrop-blur-md rounded border border-stone-200/50">
                         <span className="text-stone-800 font-medium tracking-wide">{result.subtype}</span>
                     </div>
                     <p className="mt-8 text-stone-600 max-w-lg leading-relaxed font-light">{result.description}</p>
                 </div>
                 {/* Decorative background element */}
                 <div className="absolute -bottom-20 -right-20 w-80 h-80 rounded-full bg-white opacity-20 blur-3xl"></div>
             </div>

             <div className="md:col-span-4 flex flex-col gap-4">
                 <div className="flex-1 bg-stone-50 p-6 rounded-xl border border-stone-100 flex flex-col justify-center">
                     <span className="text-[10px] font-bold text-stone-400 uppercase tracking-widest mb-2">{t.result.secondarySeason}</span>
                     <span className="text-2xl font-serif text-stone-700">{secondarySeasonName}</span>
                 </div>
                 <div className="flex-1 bg-stone-50 p-6 rounded-xl border border-stone-100 flex flex-col justify-center opacity-60">
                     <span className="text-[10px] font-bold text-stone-400 uppercase tracking-widest mb-2">{t.result.worstSeason}</span>
                     <span className="text-2xl font-serif text-stone-400 line-through">{worstSeasonName}</span>
                 </div>
             </div>
        </div>

        {/* 03. Scales */}
        <SectionHeader number="03" title={t.result.scalesTitle} />
        <div className="mb-16 bg-white p-8 rounded-xl border border-stone-100 break-inside-avoid">
             <div id="grid-scales" className="grid grid-cols-1 md:grid-cols-2 gap-12">
                <div>
                    <ScaleBar 
                        leftLabel={t.result.warm} rightLabel={t.result.cool} 
                        value={result.scales.warmToCool} colorStart="#FDBA74" colorEnd="#93C5FD" 
                    />
                    <ScaleBar 
                        leftLabel={t.result.light} rightLabel={t.result.deep} 
                        value={result.scales.lightToDeep} colorStart="#F3F4F6" colorEnd="#374151" 
                    />
                </div>
                <div>
                    <ScaleBar 
                        leftLabel={t.result.bright} rightLabel={t.result.muted} 
                        value={result.scales.brightToMuted} colorStart="#F472B6" colorEnd="#9CA3AF" 
                    />
                    <ScaleBar 
                        leftLabel={t.result.low} rightLabel={t.result.high} 
                        value={result.scales.contrastLevel} colorStart="#D1D5DB" colorEnd="#000000" 
                    />
                </div>
             </div>
        </div>
        
        {/* 04. PCCS Tone Map & Comparison (EXPANDED MODULE) */}
        <SectionHeader number="04" title={t.result.pccsTitle} />
        <div className="mb-16 break-inside-avoid">
             <SeasonalComparisonModule 
                activeSeason={result.season} 
                lang={lang} 
                userImage={userImage} 
                matches={result.seasonMatches}
             />
        </div>

        {/* 05. Style Profile */}
        <SectionHeader number="05" title={t.result.styleProfile} />
        <div className="bg-stone-900 text-stone-300 p-10 rounded-xl mb-16 shadow-2xl break-inside-avoid">
            <div id="grid-style" className="grid md:grid-cols-2 gap-12">
                <div>
                     <h4 className="text-xs font-bold text-stone-500 uppercase tracking-widest mb-6">{t.result.volume}</h4>
                     <div className="flex space-x-2">
                        <CheckBoxItem label={t.result.large} checked={result.volume === 'Large'} />
                        <CheckBoxItem label={t.result.medium} checked={result.volume === 'Medium'} />
                        <CheckBoxItem label={t.result.small} checked={result.volume === 'Small'} />
                     </div>
                </div>
                <div>
                     <h4 className="text-xs font-bold text-stone-500 uppercase tracking-widest mb-6">{t.result.shape}</h4>
                     <div className="flex space-x-2">
                        <CheckBoxItem label={t.result.curved} checked={result.shape === 'Curved'} />
                        <CheckBoxItem label={t.result.natural} checked={result.shape === 'Natural'} />
                        <CheckBoxItem label={t.result.straight} checked={result.shape === 'Straight'} />
                     </div>
                </div>
            </div>
            <div className="mt-10 pt-10 border-t border-stone-800 flex flex-col md:flex-row items-center gap-6">
                <div className="text-4xl">✨</div>
                <div>
                    <h4 className="text-white font-serif text-2xl mb-2">{result.stylePersona.description}</h4>
                    <div className="flex flex-wrap gap-2">
                         {result.stylePersona.keywords.map((kw, i) => (
                             <span key={i} className="text-[10px] font-bold uppercase tracking-wider bg-stone-800 px-3 py-1 rounded text-stone-400 border border-stone-700">#{kw}</span>
                         ))}
                    </div>
                </div>
            </div>
        </div>

        {/* 06. Recommendations */}
        <SectionHeader number="06" title={t.result.recommendationsTitle} />
        <div id="grid-recs" className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16 break-inside-avoid">
            {/* Metals - Uniform Circles */}
            <div className="bg-white p-8 rounded-xl border border-stone-200 flex flex-col items-center">
                <h4 className="text-[10px] font-bold text-stone-400 uppercase tracking-widest mb-6">{t.result.metals}</h4>
                <div className="grid grid-cols-2 gap-4">
                    {['Gold', 'Silver', 'Rose Gold', 'Champagne'].map((metal) => {
                         const isRec = result.bestMetals.some(m => m.includes(metal));
                         const metalName = t.metals ? t.metals[metal as keyof typeof t.metals] : metal;
                         let bg = '#E5E5E5';
                         if (metal === 'Gold') bg = '#D4AF37';
                         if (metal === 'Silver') bg = '#C0C0C0';
                         if (metal === 'Rose Gold') bg = '#B76E79';
                         if (metal === 'Champagne') bg = '#F7E7CE';
                         
                         return (
                             <div key={metal} className={`w-16 h-16 rounded-full flex items-center justify-center transition-all ${isRec ? 'opacity-100 shadow-md ring-2 ring-offset-2 ring-stone-200' : 'opacity-20 grayscale'}`} style={{backgroundColor: bg}}>
                                 {isRec && <span className="text-[8px] font-bold uppercase bg-white/80 px-1 rounded text-stone-900">{metalName}</span>}
                             </div>
                         )
                    })}
                </div>
            </div>

            {/* Hair Color - Uniform Circles With Names */}
            <div className="bg-white p-8 rounded-xl border border-stone-200 flex flex-col items-center">
                <h4 className="text-[10px] font-bold text-stone-400 uppercase tracking-widest mb-6">{t.result.hairColor}</h4>
                <div className="grid grid-cols-3 gap-y-4 gap-x-2">
                    {result.hairColors.slice(0, 6).map((c, i) => (
                        <div key={i} className="flex flex-col items-center">
                            <div className="w-10 h-10 rounded-full border border-stone-100 shadow-sm mb-1" style={{backgroundColor: c.hex}}></div>
                            <span className="text-[8px] text-stone-500 text-center leading-tight max-w-[60px]">{c.name}</span>
                        </div>
                    ))}
                </div>
            </div>

            {/* Accessories Info */}
            <div className="bg-white p-8 rounded-xl border border-stone-200">
                <h4 className="text-[10px] font-bold text-stone-400 uppercase tracking-widest mb-4">{t.result.accessories}</h4>
                <div className="flex flex-wrap gap-2 mb-8">
                     {result.accessoryMaterials.map((m, i) => (
                         <span key={i} className="px-2 py-1 bg-stone-50 border border-stone-200 text-stone-600 text-xs rounded">{m}</span>
                     ))}
                </div>
                <h4 className="text-[10px] font-bold text-stone-400 uppercase tracking-widest mb-4">{t.result.fabrics}</h4>
                <div className="flex flex-wrap gap-2">
                     {result.fabricTextures.map((m, i) => (
                         <span key={i} className="px-2 py-1 bg-stone-50 border border-stone-200 text-stone-600 text-xs rounded">{m}</span>
                     ))}
                </div>
            </div>
        </div>

        {/* 07. Palette - Uniform Aspect Ratio Cards */}
        <SectionHeader number="07" title={t.result.paletteTitle} />
        <div id="grid-palette" className="grid md:grid-cols-2 gap-10 break-inside-avoid">
            <div>
                 <div className="flex items-center justify-between mb-4">
                     <span className="text-xs font-bold text-stone-900 uppercase tracking-wider">{t.result.bestPalette}</span>
                 </div>
                 <div className="grid grid-cols-5 gap-2">
                     {result.palette.bestColors.map((c, i) => (
                         <div key={i} className="aspect-[3/4] rounded-md shadow-sm transition-transform hover:-translate-y-1" style={{backgroundColor: c.hex}} title={c.name}></div>
                     ))}
                 </div>
            </div>
            <div>
                 <div className="flex items-center justify-between mb-4">
                     <span className="text-xs font-bold text-stone-400 uppercase tracking-wider">{t.result.avoidPalette}</span>
                 </div>
                 <div className="grid grid-cols-5 gap-2 opacity-50 grayscale-[0.3]">
                     {result.palette.worstColors.map((c, i) => (
                         <div key={i} className="aspect-[3/4] rounded-md shadow-sm" style={{backgroundColor: c.hex}} title={c.name}></div>
                     ))}
                 </div>
            </div>
        </div>

      </div>
      {/* --- REPORT END --- */}

      {/* Footer Controls */}
      <div className="mt-12 text-center flex justify-center space-x-4 no-print">
        <button 
          onClick={handleDownload}
          disabled={isDownloading}
          className="px-8 py-3 bg-stone-900 text-white text-sm font-medium rounded-full shadow-xl hover:shadow-2xl hover:bg-black transition-all disabled:opacity-50"
        >
          {isDownloading ? 'Generating PDF...' : t.result.download}
        </button>

        <button 
          onClick={onReset}
          className="px-8 py-3 bg-white text-stone-900 border border-stone-200 text-sm font-medium rounded-full shadow-sm hover:shadow-md hover:border-stone-300 transition-all flex items-center"
        >
          <RefreshIcon className="w-4 h-4 mr-2" />
          {t.result.reset}
        </button>
      </div>
    </div>
  );
};

export default ResultView;
